library(ape)


pi <- function(seq_df){
  aln <- as.DNAbin(tolower(t(as.matrix(seq_df))))
  pdm <- dist.dna(aln, model = "raw", pairwise.deletion=TRUE, as.matrix = TRUE)
  pdm[upper.tri(pdm, diag = TRUE)] <- NA
  return(mean(pdm, na.rm = T))
  }


fst <- function(seq_df, popA, popB){
  pi_T <- pi(seq_df[,c(popA,popB)])
  pi_A <- pi(seq_df[,popA])
  pi_B <- pi(seq_df[,popB])
  w = length(popA) / (length(popA) + length(popB))
  pi_S <- pi_A*w + pi_B*(1-w)
  return((pi_T - pi_S)/pi_T)
  }

